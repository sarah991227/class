$(function(){
   const menu = $("#top_menu ul > li");
   const contents= $("#contents > div");
   menu.click(function(event){
    const tg = $(this);
    //this는 내가 선택한 li
    const i = tg.index();
    //첫번째 li 는 index 번호가 0번
    const section = contents.eq(i);
    //contents 가 3개 들어있음
    const tt = section.offset().top;
    //문서 처음부터 div(0) 있는데까지의 지점

    $("html,body").stop().animate({scrollTop:tt});
   });

   $(window).scroll(function(){
    const sct = $(window).scrollTop();
    //scroll 이 이동한 거리 저장
    contents.each(function(){
        //contents 에 각각 div 에 대해서
        const tg1 = $(this);
        //첫번재 거 작업할땐 this가 첫번째꺼 두번째꺼 작업할땐 this 가 두번째
        const i = tg1.index();
        //this의 index 를 저장해라
        if(tg1.offset().top <= sct){
        //scroll 한 거리가 div(this) 의 위치보다 더 크면 그러면 바꿔야된다
            menu.removeClass("on");
            menu.eq(i).addClass("on");
            //menu li 의 (div index)번째 에 on 을 붙이고 css 를 바꿔라
        }
    });
   });
});