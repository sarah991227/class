<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">

</head>
<body>
    <?php
        $a=3;
        $b=2;

        $a = $a + $b;
        $b = $a + 5;
        $c = $a * $b;

        $c = $c % 2;
        $a = $b + $c;
        $b = $a * $b;

        echo "a : $a, b : $b, c : $c";
    ?>
</body>
</html>