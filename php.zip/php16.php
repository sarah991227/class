<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">
</head>
<body>
    <?php
        for($a = 2;$a<= 9; $a++)
        {
            for($b= 1;$b<=9;$b++)
            {
                $c = $a *$b;
                echo("$a x $b = $c <br>");
            }

            echo("---------------<br>");
        }
    ?>
</body>
</html>