<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">

</head>
<body>
<!-- $num = 80; 2 로 나눈나머지가 0 과 같으면 짝수, 아니면 홀수 -->
    <?php
        $num = 80;
        if ($num % 2 == 0)
        {
            echo "$num 은(는) 짝수다.";
        }
        else
        {
            echo "$num 은(는) 홀수다.";
        }
    ?>
</body>
</html>