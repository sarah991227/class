<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">
</head>
<body>
    <?php
        function plus($a,$b)
        {
            $c = $a + $b;
            return $c;
        }
        $result = plus(15,25);
        echo $result."<br>";
        $result = plus(3500,1500);
        echo $result;

    ?>
</body>
</html>