<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">

</head>
<body>
    <?php
//90이상 점수 ==> A 80이상 점수 ==> B 70이상 점수 ==> C
//60이상 점수 ==> D 아니면 ==>F 
    $a = 85;
    if($a >= 90)
        echo "$a ==> A";
    elseif($a >=80)
        echo "$a ==> B";
    elseif($a >=70)
        echo "$a ==> C";
    elseif($a >=60)
        echo "$a ==> D";
    else
        echo "$a ==> F";
    ?>
</body>
</html>