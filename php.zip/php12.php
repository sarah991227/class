<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">

</head>
<body>
    <?php
    $i = 100;
    do{
        echo $i. "<br>";
    }while ($i <=10)
    //do while 의 특징은 조건이 안맞아도 무조거 한번은 실행한다
    //while 이 앞에 있으면 아무것도 실행되지 않는다
    ?>
</body>
</html>