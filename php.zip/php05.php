<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel = "stylesheet" href = "css/reset.css">

</head>
<body>
    <?php
        $n1 = "010";
        $n2 = "2322";
        $n3 = "3233";

        $hp = $n1. "-" .$n2. "-" .$n3;
        echo "휴대폰 번호 : $hp";
    ?>
</body>
</html>