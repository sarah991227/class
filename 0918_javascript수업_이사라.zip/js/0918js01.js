
//큰 이미지 아이디를 불러오는것
const bigPic = document.querySelector("#cup");
//document.querySelectorAll 여러개를 갖고오는것, 집합으로 갖고올땐 배열로 들어온다, class=small 인것들을 모두 갖고와라
const smallPics = document.querySelectorAll(".small");
// smallPics[0],smallPics[1],smallPics[2] 로 저장됨 반복문 사용함
for(i = 0; i <smallPics.length;i++){
    smallPics[i].addEventListener("click", function(){//클릭을 감지하면 다른 함수를 실행하시요, 감지 못하면 빠져나감
        newPic = this.src; // 현재 선택한애를 newPic 에 저장해라
        bigPic.setAttribute("src", newPic);
        // biPic 의 src 를 newPic src 로 바꿔라
        //.setAttribute(속성이름, 값) : 특정 속성에 값을 지정한다
        //.getAttribute(속성이름, 값) : 특정 속성을 추출한다
    });
    //function 이 복잡할때의 format
    //smallPics[i].addEventListener("click", function);
    //function(){}
    //포인트: function 을 부를때 ()을 사용하지 않는다.
}