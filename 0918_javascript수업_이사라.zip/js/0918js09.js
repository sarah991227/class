let elForm, elSelectPackage, elPackageHint, elTerms, elTermsHint;
elForm          = document.getElementById('formSignup');        
elSelectPackage = document.getElementById('package');
// 셀렉트박스
elPackageHint   = document.getElementById('packageHint');
// 셀렉트박스 메세지
elTerms         = document.getElementById('terms');
// 체크박스
elTermsHint     = document.getElementById('termsHint');
// 체크박스 메세지

function packageHint() {        
// 값이 변경될때 호출한다
//임시로 저장한다 이번에 선택한 값을
//저장한 값이  option value 'monthly'이면 packageHint 에 메세지를 넣어라
  pack = this.options[this.selectedIndex].value;//selectedIndex 는 script에 내장되어있는언어 첫번째 선택할시 this.options[0].value 즉 옵션중의 첫번째의 value

  if (pack == 'monthly') {                          
    elPackageHint.innerHTML = '1년 패키지를 사용하시면 10불을 절약할 수 있습니다.!';
  } else {                                           
    elPackageHint.innerHTML = 'Wise choice!';       
  }
}

function checkTerms(e) {    
//함수를 호출했을때 체크박스가 체크되어있지 않으면 체크박스 메세지를 넣어라
  if (!elTerms.checked) {                          
    elTermsHint.innerHTML = '사용권 계약에 동의해야 합니다.';
    e.preventDefault();         
     //a처럼 버튼이나 체크벅스를 누를때 넘어가는 속성이 있다, 이 본연의 속성을 막아주는것.                   
  }
}  

//function 을 만들어 놓고 밑에서 이제 호출을 한다


elForm.addEventListener('submit', checkTerms, false);
//submit 이벤트 사용
//submit 를 눌렀을때 checkTerms 함수를 호출
elSelectPackage.addEventListener('change', packageHint, false);
//change 이벤트 사용. 값이 변경 되었을때 발생하는 이벤트
//값이 변경 됬을때 packageHint 함수를 호출
