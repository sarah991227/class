const bigPic = document.querySelector("#main img");
//img 의 src 를 바꿔야하기때문에 #main img 까지 써준다. 
//이 이미지엔 따로 아이디나 클라스가 없다 그래서 이런 형식으로 써준다
const smallPics = document.querySelectorAll("#navi ul li a");
//a 를 다르게 할것이기 때문에 a까지 써준다
for(let i =0; i<smallPics.length;i++){
    smallPics[i].addEventListener("click", function(e){//작은 이미지들 중에서 click 이벤트가 감지될 경우
        const newPic = this.href; //현재 이미지의 주소를 저장
        bigPic.setAttribute("src", newPic);//큰이미지의 주소를 현재 이미지의 주소로 변경
        e.preventDefault(); //a의 본래 event 속성을 차단해야함 매우 중요함!!!
        //function(e), e.preventDefault() 는 세트
        //차단하지 않으면 이미지가 바뀌지 않고 새로운 페이지로 불려감
    })
}