const numbers = [2,4,6,8,10];//배열 지정
showArray(numbers);//함수를 호출할때 배열을 넘김

function showArray(arr){
    let str = "<table><tr>";//테이블, 행 태그
    for (let i = 0; i <arr.length;i++){//0 에서 배열의 길이만큼만
        str += "<td>" + arr[i] + "</td>";//배열의 값을 뽑아서 테이블 데이타에 집어 넣는다
    }
    str += "</tr></table>";//행, 테이블 태그 닫음
    document.write(str);
}