const firstItem = document.getElementById("one");//id=one 을 불러와서 firstItem 에 저장
if(firstItem.hasAttribute("class")){//class라는 속성이 있냐 없냐
    const attr = firstItem.getAttribute("class");//클라스 가 hot이기때문에 attr = hot
    const el = document.getElementById("text");//id=text을 불러와서 el에 저장
    el.innerHTML = "<p>The first item has a class name : " + attr + "</p>";
    //text 의 innerHTML은 hot
}