function checkUsername(){
    const elMsg = document.getElementById('feedback');//id=feedback 을 불러와라
    if(this.value.length < 5){
        //커서가 깜빡이지 않을때 의 username 이 5글자 미만이면 feedback 을 표시
        elMsg.innerHTML = '이름은 다섯 글자 이상이어야 합니다.';
    }else{
        //그외 feedback 표시하지 말것.
        elMsg.innerHTML = '';
    }
}
//10번 줄이 제일 먼저 실행됨 호출해야지 함수가 실행됨
const uname = document.getElementById('username');//id=username 을 불러와라

//cursor 깜빡이는 상태 는 focus 그 반대는 blur 
uname.addEventListener('blur',checkUsername);//함수 부를때 () 넣지 않는다
//cursor 가 깜빡이지 않을때 checkUsername 함수를 부른다



//uname.addEventListener('blur',checkUsername,false);
//addEventListener(이벤트 이름, 함수이름, false)가 기본 형식