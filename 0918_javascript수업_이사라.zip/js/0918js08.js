let el;

function charCount(e){
    let textEntered,charDisplay, counter, lastkey;
    textEntered = document.getElementById('message').value;
    charDisplay = document.getElementById('charactersLeft');
    counter = (180-(textEntered.length));
    charDisplay.innerHTML = counter;
    lastkey = document.getElementById('lastKey');
    lastkey.innerHTML = "ASCII code: " + e.keyCode;
}
el = document.getElementById('message');
el.addEventListener('keypress', charCount, false);
// keypress 는 키보드 이벤트 => 사용자가 키보드의 키를 눌렀다 떼면서 문자가 화면에 나타나게 되면 이벤트 발생
//어떤 키가 눌렸는지 알려주는 keycode 속성을 가지고 있음
//keypress이벤트 발생시 charCount 함수 불러