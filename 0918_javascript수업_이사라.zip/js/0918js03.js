const buttons = document.querySelectorAll(".check");//class=check들을 모두 불러라
for(let i = 0; i<buttons.length;i++){//class=check인것들의 반복문
    buttons[i].addEventListener("click",function(){//click이벤트 발생된게 있으면 즉 클릭하면 함수를 불러라 
        this.parentNode.style.color = "#ccc";
        //함수: 현재 선택한 것의 부모의 색깔을 회색으로 바꿔라
        //즉 li 의 색깔을 바꿔라
        //parentNode, childNodes, firstchild, lastChild, nextSibling,previousSibling
    });
}