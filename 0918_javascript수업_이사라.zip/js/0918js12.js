const userId = document.querySelector("#user-id");
const pw1 = document.querySelector("#user-pw1");
const pw2 = document.querySelector("#user-pw2");

//값이 변경되고 포커스를 잃을때 onchange 가 발생
userId.onchange = checkId;//checkId 함수 호출
pw1.onchange = checkPw;//checkPw 함수 호출
pw2.onchange = comparePw;//comparePw 함수 호출

function checkId(){
    if(userId.value.length < 4 || userId.value.length > 15){//userId 의 길이가 4 보다 작거나 15부다 크면 
        alert("4-15자리의 영문과 숫자를 사용하세요.");
        userId.select();//편리하게 다시 입력할 수 있게 userid를 파란색으로 셀렉트 해라
    }
}

function checkPw(){
    if(pw1.value.length < 8){//pw1의 길이가 8 보다 작으면
        alert("비밀번호는 8자리 이상이어야 합니다.");
        pw1.value = "";//reset pw
        pw1.focus();//커서를 입력칸에 넣는다.
    }
}

function comparePw(){
    if(pw1.value != pw2.value){//pw1 와 pw2 의 값이 똑같지 않으면
        alert("암호가 다릅니다. 다시 입력하세요. ")
        pw2.value = "";//reset pw
        pw2.focus();//커서를 입력칸에 넣는다.
    }
}