function checkUsername(){
    const username = el.value;
    if(username.length < 5){
        elMsg.innerHTML = 'Not long enough, yet...';
    } else{
        elMsg.innerHTML = '';
    }
}

function tipUsername(){
    elMsg.innerHTML = 'Username must be at least 5 characters';
}

//마찬가지로 여기가 먼저 실행된다
const el = document.getElementById('username');
const elMsg = document.getElementById('feedback');

el.addEventListener('focus', tipUsername, false);//커서가 깜빡일때 tipUserName 불러
el.addEventListener('blur', checkUsername,false);//커서가 깜빡이지 않을때 checkUserName 불러