//ul li 를 javascript 로 만든다
const itemList = [];//비여있는 배열을 하나 만들고 집어 넣는다

const addBtn = document.querySelector("#add");
addBtn.addEventListener("click", addList);//추가버튼을 눌렀을때 addList 함수를 불러라

function addList(){
 const item = document.querySelector("#item").value;
//  id item 의 값을 저장해라
 if(item!=null){//null 은 아무것도 없다를 뜻한다. item 의 값이 null 이 아니면 item 에 뭐가 있다는 뜻
  itemList.push(item);//비여있는 배열에 item 을 집어넣어라
  document.querySelector("#item").value = "";//id item 즉 text 넣는 곳을 이제 비워라(적어 있던걸 집어 넣으니 이제 초기화하는것)
  document.querySelector("#item").focus();//커서 깜빡이게 하는것
 }
 showList();//함수
}

function showList(){
  let list= "<ul>"; //ul 태그를 저장해라
  for(let i = 0; i <itemList.length;i++){//ul 에 이어서 itemList 개수 만큼 li 을 만든다
    list += "<li>" + itemList[i] + "<span class = 'close' id =" + i + ">X</span></li>"; //itemList 에서 i번재 item 을 넣고, 나중에 지우고싶으면 지울수 있게 span 으로 class=close 지정하고 id는 i번째 지정한다
  }
  list += "</ul>"//맨 끝에 ul 태그 가 있어야지 format 이 완서오딘다
  document.querySelector('#itemList').innerHTML = list;//id itemList 를 찾아서 그안에 list가 보이게금 해라
  const remove = document.querySelectorAll(".close");//close class 인 애들을 모두 remove 에 array 로 저장해라
  for(let i = 0; i<remove.length; i++){
    remove[i].addEventListener("click", removeList);
    //X 가 눌러질때마다 removeList()를 불러라
  }
}

function removeList(){
const id = this.getAttribute("id");//현재 선택한 아이의 id 를 읽어와서 변수에 저장해라
itemList.splice(id,1);//index id 의 요소를 지워라
//splice 함수: 
//const fruits = ['수박', '바나나', '망고', '두리안']
//const removed = fruits.splice(2,1);
//2번 index 에서 1개 지워라 -->'망고'가 지워짐
showList();//지운다움에 나머지를 보여줘라 그래서 showList를 또 불러야함
}