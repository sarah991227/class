create table sungjuk(
    id varchar(8),
    name varchar(12),
    kor varchar(8),
    eng varchar(8),
    mat varchar(8),
    primary key(id)
)