<!-- php굳이 안써도 됨 -->
<?php
    session_start();
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
<style>

tr,td {text-align:center;}
table {padding:20px;box-sizing:border-box;}
.tb {border:none;}
tr, td {border:none;}
 
</style>
<body>
    <h3>성적 입력 하기</h3>
    <form action = "insert.php" method = 'post'>
    <!-- form 에서 입력된거는 post 방식(숨김방식으로) insert.php로 간다 -->
    <table width = "1500" border = "2">
        <tr><td>
            ID: <input type = "text" size = "6" name = "id">&nbsp;
            <!-- $nbsp 는 non-breaking space(줄바꿈이 일으키지 않는 공백)  -->
            이름: <input type = "text" size = "6" name = "name">&nbsp;
            국어: <input type = "text" size = "6" name = "kor">&nbsp;
            영어: <input type = "text" size = "6" name = "eng">&nbsp;
            수학: <input type = "text" size = "6" name = "mat">   
        </td>
        <td>
            <input type = "submit" value = "입력하기">
            <!-- 입력하기 버튼을 누르면 insert.php로 전송된다 -->
        </td>
        </tr>
    </table>
    </form>
<?
    include "dbconn.php";
    $sql = "select * from sungjuk";
    // 성적sql에서 모든걸 선택한다
    $result = mysqli_query($connect,$sql);
    //db에 접속한다
    mysqli_close($connect);
    //db 접속 끊는다
?>
</body>
</html>