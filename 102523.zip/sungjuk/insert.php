<?
    session_start();
?>
<meta charset= "utf-8">

<?
    $id = $_POST['id'];
    $name = $_POST['name'];
    $kor = $_POST['kor'];
    $eng = $_POST['eng'];
    $mat = $_POST['mat'];

    include "dbconn.php";

    // 연결시켜주는 작업
    $sql = "select * from sungjuk";
    $result = mysqli_query($connect,$sql);

    //인서트하는작업
    $sql = "insert into sungjuk(id,name,kor,eng,mat) values";
    $sql .= "('$id','$name', '$kor', '$eng','$mat')";
    $result = mysqli_query( $connect,$sql);

    // DB 접속 끊기
    mysqli_close($connect);    
    echo "
    <script>
     location.href = 'sungjuk_ex.php';
    </script>
    ";
 ?>
  

