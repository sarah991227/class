<?
           session_start();
         //   값을 넘기고 받고 해야되기때문에 유지해야됨
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
<style>

   tr,td {text-align:center;}
   table {padding:20px;box-sizing:border-box;}
   .tb {border:none;}
    tr, td {border:none;}
    
   </style>
<body>
<h3>1) 데이터 입력 하기</h3>

<form action="insert.php" method='post'>
<table width="720" border="1" >
    <tr><td> 
             ID : <input type="text" size="6" name="id">&nbsp;
             <!-- 네임이 반드시 있어야됨 -->
             이름 : <input type="text" size="6" name="name">&nbsp;
             주소 : <input type="text" size="20" name="addr">
             
	</td>
       <td>
	    <input type="submit" value="입력하기">	
       <!-- 입력하기 버튼을 누르면 insert.php로 전송한다(숨겨서:post 방식) -->
       </td>
    </tr>
 </table>
 </form>
 

 <!-- <table width="720" border="1" class="tb">
 <tr>
 <td>ID</td>
 <td>이름</td>
 <td>주소</td>
  </tr> -->
 

  <?
 include "dbconn.php";   
 $sql = "select * from addrdb";
     
 
    $result = mysqli_query($connect,$sql);
  
 
    
 
    mysqli_close($connect);                   // DB 접속 끊기
 
 ?>
</table>

</body>
</html>