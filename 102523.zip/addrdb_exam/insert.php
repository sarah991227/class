<?
           session_start();
?>
  <meta charset="utf-8">

<?
// 값을 받는 작업
  $id=$_POST['id'];
  $name = $_POST['name'];
  $addr=$_POST['addr'];


include "dbconn.php";       // dconn.php 파일을 불러옴
      //mysqli_query($connect,'set names utf8');  //닷홈에 한글깨질때 db연결아래에 써줌
     // mysqli_query($connect,$sql); 

      $sql = "select * from addrdb";
      // table이름 검색해서 연결시켜주기
      $result = mysqli_query( $connect,$sql);
     
    
       
/*
  if ($connect->connect_error) {
   die("연결 실패 : " .$conn->connect_error); // 연결 실패 시 원인을 출력한다
 } else {
   echo "연결 성공"; // 연결 성공 시 웹 페이지 좌상단에 연결 성공이라는 문구를 출력한다
 }
*/
      
      // 연결했기때문에 인서트 할 수 있음
      $sql = "insert into addrdb(id,name, addr) values";
      $sql .= "('$id','$name', '$addr')";
     
/*
      if (!mysqli_query($connect,$sql))
      {
      die('Error: ' . mysqli_error($con));
      }
    echo "1 record added";
*/

        $result = mysqli_query( $connect,$sql);
      

 

 
    mysqli_close($connect);    // DB 접속 끊기
    echo "
    <script>
     location.href = 'addr_ex.php';
    </script>
 ";
 
 ?>
  
 </table>
