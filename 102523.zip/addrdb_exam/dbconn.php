<?
 $connect=mysqli_connect( "localhost", "DB아이디", "DB비밀번호","DB아이디") or  
        die( "SQL server에 연결할 수 없습니다."); 

    mysqli_select_db($connect,"DB아이디");

?>