create table addrdb(
	id varchar(8),
	name varchar(12),
	addr varchar(30),
	primary key(id)
);