<footer>    
 <ul class="foot"    >
 <li><a href="#">첼린지코리아</a><span>|</span></li>
 <li><a href="#">첼린지코리아</a><span>|</span></li>
 <li><a href="#">클라이언트</a><span>|</span></li>
 <li><a href="#">인재채용</a><span>|</span></li>
 <li><a href="#">홍보자료</a><span>|</span></li>
 <li><a href="#">사업제휴문의</a><span>|</span></li>
 <li><a href="#">Contact Us</a><span>|</span></li>
 </ul>

 <p class="last"><img src="images/blogo.png" alt=""></p>
  <div class="addr">
 <p>
서울시 광진구 자양동 682-28 고려빌딩 2F (주) 첼린지코리아 TEL:02)3437-6104</p>
<small>Copyright &copy; CHALLENGE KOREA Corp All Rights. Reserved</small>
 </div>
</footer>	 
</body>
</html>