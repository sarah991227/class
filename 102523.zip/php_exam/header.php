<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/challenge.css">


		
	</head>
	<body>
		<header>
  <h1><a href="index.html"><img src="images/logo.jpg" alt=""></a></h1>
        <nav id="menu">
        	<ul class="navi">
            	<li><a href="#">Story</a>
					<ul class="sub">
					<li><a href="sub.html">브랜드이야기</a></li>      
					<li><a href="#">커피이야기</a></li>
					<li><a href="#">디저트이야기</a></li>
				
					</ul>
				</li>

<li><a href="#">Product</a>
<ul class="sub sub2">
<li><a href="#">신제품</a></li>      
<li><a href="#">디저트</a></li>
<li><a href="#">케이크</a></li>
<li><a href="#">커피&음료</a></li>
</ul>
</li>

<li><a href="#">EVENT</a>
<ul class="sub sub3">
<li><a href="#">당첨자발표</a></li>      
<li><a href="#">매장별이벤트</a></li>
<li><a href="#">멤버십</a></li>
</ul>
</li>

<li><a href="#">INFO</a>
<ul class="sub sub4">
<li><a href="#">창업정보</a></li>      
<li><a href="#">온라인창업</a></li>
<li><a href="#">FAQ</a></li>
</ul>
</li>
<li><a href="#">Customer</a>
<ul class="sub sub5">
<li><a href="#">고객센터</a></li>      
<li><a href="#">홍보관</a></li>
</ul>
</li>
<li><a href="#">Board</a>
<ul class="sub sub5">
<li><a href="#">공지사항</a></li>      
<li><a href="#">게시판</a></li>
</ul>
</li>
<li><a href="#">About us</a>
<ul class="sub sub5">
<li><a href="#">회사소개</a></li>      
<li><a href="#">위치</a></li>
</ul>
</li>
</ul>
  </nav>
</header>